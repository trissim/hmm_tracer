#!/usr/bin/env python
# coding: utf-8

# In[1]:


__author__ = 'Alvason Zhenhua Li'
__version__ = '0.0.3'

'''
(The __init__.py file is required to make Python treat the directory as containing a package)
'''

