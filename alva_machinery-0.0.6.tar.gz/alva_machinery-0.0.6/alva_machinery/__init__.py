#!/usr/bin/env python
# coding: utf-8

# In[ ]:


__author__ = 'Alvason Zhenhua Li'
__version__ = '0.0.6'

'''
(The __init__.py file is required to make Python treat the directory as containing a package)
'''

